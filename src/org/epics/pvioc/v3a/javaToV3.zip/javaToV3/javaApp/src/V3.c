#include "org_epics_ioc_v3a_V3.h"

JNIEXPORT void JNICALL Java__V3_iocsh(JNIEnv *env, jclass cls, jstring str)
{
    const char* fileName;
    jboolean isCopy;

    fileName = (*env)->GetStringUTFChars(env,str,&isCopy);
    printf("filename %s\n",fileName);
    iocsh(fileName);
}
