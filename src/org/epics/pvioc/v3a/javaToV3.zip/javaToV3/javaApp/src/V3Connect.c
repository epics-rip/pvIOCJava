#include "V3Connect.h"

JNIEXPORT void JNICALL Java_V3Connect_startV3(JNIEnv* env, jclass cl)
{
    printf("Hello here I am\n");
    iocsh("/home/install/epics/test/javaToV3/javaApp/st.cmd");
    printf("after iocsh\n");
    iocsh(0);
}
