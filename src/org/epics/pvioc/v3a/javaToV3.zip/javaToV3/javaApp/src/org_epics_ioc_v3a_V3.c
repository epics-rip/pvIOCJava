#include "org_epics_ioc_v3a_V3.h"

JNIEXPORT void JNICALL Java_org_epics_ioc_v3a_V3_iocsh(JNIEnv *env, jclass cls, jstring str)
{
    const char* fileName;
    jboolean isCopy;

    fileName = (*env)->GetStringUTFChars(env,str,&isCopy);
    if(fileName==0 || fileName[0]== 0) {
        iocsh(0);
    } else {
        printf("filename |%s|\n",fileName);
        iocsh(fileName);
    }
}
