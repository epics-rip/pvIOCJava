#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "org_epics_ioc_v3a_AsynOctet.h"

typedef struct myStuff{
    int value;
}myStuff;

JNIEXPORT jlong JNICALL Java_org_epics_ioc_v3a_AsynOctet_init(
    JNIEnv *env, jobject thisObj, jobject asynUser)
{
    int pointerSize = sizeof(void *);
    jlong retValue = 0;
    myStuff *pmyStuff = calloc(1,sizeof(myStuff));
    if(pointerSize==4) {
        jint valueInt = (jint)pmyStuff;
        retValue = (jlong)valueInt;
    } else if(pointerSize==8) {
        retValue = (jlong)pmyStuff;
    } else {
        fprintf(stdout,"pointerSize %d\n",pointerSize);
    }
    fprintf(stdout,"pmystuff %p\n",pmyStuff);
    fflush(stdout);
    return retValue;
}

JNIEXPORT jint JNICALL Java_org_epics_ioc_v3a_AsynOctet_read
  (JNIEnv *env, jobject thisObj, jlong cPvt, jobject asynUserObj)
{
    myStuff *pmyStuff = 0;
    int pointerSize = sizeof(void *);
    if(pointerSize==4) {
        jint intValue = (jint)cPvt;
        pmyStuff = (myStuff *)intValue;
    } else if(pointerSize==8) {
        pmyStuff = (myStuff *)cPvt;
    } else {
        fprintf(stdout,"pointerSize %d\n",pointerSize);
    }
    fprintf(stdout,"pmystuff %p\n",pmyStuff);
    fflush(stdout);
    return 0;
}
